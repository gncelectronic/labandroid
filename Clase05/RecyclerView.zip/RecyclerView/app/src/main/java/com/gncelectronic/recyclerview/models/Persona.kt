package com.gncelectronic.recyclerview.models

data class Persona(val nombre:String, val apellido:String, val edad:Int, val fotoRef:Int) {
}