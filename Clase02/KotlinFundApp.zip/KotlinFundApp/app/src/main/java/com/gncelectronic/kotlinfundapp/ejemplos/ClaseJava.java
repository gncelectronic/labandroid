package com.gncelectronic.kotlinfundapp.ejemplos;

public class ClaseJava {
    public static Exception getNPE(){
        return new NullPointerException();
    }
}
